
import { GoogleGenAI, Modality } from "@google/genai";
import type { GenerateThumbnailParams, Part } from '../types';

const fileToGenerativePart = async (file: File): Promise<Part> => {
  const base64EncodedDataPromise = new Promise<string>((resolve) => {
    const reader = new FileReader();
    reader.onloadend = () => {
        if (typeof reader.result === 'string') {
            resolve(reader.result.split(',')[1]);
        } else {
            resolve(''); // Should not happen with readAsDataURL
        }
    };
    reader.readAsDataURL(file);
  });
  return {
    inlineData: { data: await base64EncodedDataPromise, mimeType: file.type },
  };
};

export const generateThumbnails = async (
  params: GenerateThumbnailParams,
  imageFile: File | null
): Promise<string[]> => {
  if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable is not set.");
  }
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const model = 'gemini-2.5-flash-image';
  
  const { title, text, theme, gender, withBanner, editInstruction, aspectRatio } = params;
  const finalAspectRatio = aspectRatio;
  
  // Split theme string into an array, trim whitespace, and filter out empty strings.
  const themes = theme.split(',').map(t => t.trim()).filter(Boolean);
  if (themes.length === 0) {
    // Fallback if the user somehow submits an empty but required theme field.
    themes.push('photorealistic'); 
  }

  // Helper function to cycle through the provided themes for each of the 3 generations.
  const getThemeForIndex = (index: number) => themes[index % themes.length];
  
  let requestPartsArray: Part[][] = [];

  const bannerInstruction = withBanner
    ? 'The text (both title and subtitle, if present) MUST be placed on a solid, semi-transparent, or creatively shaped banner/background shape to ensure maximum readability and make it pop from the background.'
    : 'Integrate the text directly onto the image. Use high-contrast outlines, drop shadows, or outer glows to ensure text is perfectly legible. Avoid using a plain, solid banner behind the text unless it is a core part of the requested theme (e.g., a "news report" style).';

  const getAspectRatioInstruction = (ratio: string): string => {
    switch (ratio) {
      case '1:1':
        return 'a 1:1 square aspect ratio (1080x1080 pixels)';
      case '9:16':
        return 'a 9:16 vertical aspect ratio (1080x1920 pixels)';
      case '16:9':
      default:
        return `a 16:9 horizontal landscape aspect ratio (1920x1080 pixels)`;
    }
  };

  const aspectRatioInstruction = getAspectRatioInstruction(finalAspectRatio);

  const universalPromptPrefix = `
**HIGHEST PRIORITY TASK: The generated image's aspect ratio MUST BE EXACTLY ${finalAspectRatio}.**
- The output image dimensions must conform to ${aspectRatioInstruction}.
- This instruction is the most critical part of the prompt. Do not ignore it under any circumstances.
- After conforming to the aspect ratio, proceed with the following creative instructions:
---
`;


  if (imageFile && gender === 'edit') {
    if (!editInstruction) throw new Error("Edit instruction is required for edit mode.");
    const imagePart = await fileToGenerativePart(imageFile);
    const creativeDirections = [
        `Creative Direction 1 (Subtle Edit, Bold Text): Perform the edit flawlessly but subtly. The text should be the main focus, using a bold, high-impact font with strong contrast.`,
        `Creative Direction 2 (Artistic Edit, Integrated Text): Interpret the edit instruction with an artistic flair. The text should be elegantly integrated into the scene, feeling like a natural part of the edited composition.`,
        `Creative Direction 3 (Dramatic Edit, Cinematic Text): Make the edit dramatic and visually striking. The text should have a cinematic style, perhaps with a glow, gradient, or a unique placement that enhances the drama.`
    ];
    requestPartsArray = creativeDirections.map((direction, index) => {
        const currentTheme = getThemeForIndex(index);
        const promptHeader = `
You are an expert image editor and in-painter. Your task is to edit the provided image based on the user's instructions and then add text to it, creating three visually distinct options suitable for a YouTube thumbnail.

**1. Image Editing Task:**
- **Instruction:** "${editInstruction}"
- **Action:** Carefully follow the instruction to modify the original image. If removing an element (like text or an object), you must expertly remove it and realistically reconstruct the background behind it (in-painting). The result should be seamless and look as if the element was never there.

**2. Text Overlay Task (After Editing):**
After editing the image, you must overlay the following text. The text style should complement the **Primary Theme/Style**.
- **Primary Theme/Style for Text:** "${currentTheme}"

**ABSOLUTE CRITICAL TEXT RULE: You must use the following text VERBATIM. This means character-for-character, with exact spelling, capitalization, and punctuation. Double-check your spelling before finalizing the image. Any spelling mistake is a failure.**
- **Title Text (Verbatim):** "${title}"
- **Subtitle Text (Verbatim):** ${text ? `"${text}"` : 'None'}

**3. Final Design and Layout Rules:**
- **Text Readability Rule:** ${bannerInstruction}
- Text must be highly legible and strategically placed. **Crucially, do not place any text over a person's face.**
- Do not include any branding like the YouTube logo or play buttons.
- Return ONLY the generated image file. No additional commentary.
`;
        const promptText = `${universalPromptPrefix}${promptHeader}\n\n**Creative Direction for this version:** ${direction}`;
        return [imagePart, { text: promptText }];
    });
  } else if (imageFile && gender === 'original') {
    const imagePart = await fileToGenerativePart(imageFile);
    const textCreativeDirections = [
        `Text Style 1 (Bold & Loud): Use a thick, impactful, sans-serif font (like 'Bebas Neue' or 'Anton'). The text should be large and demand attention. Apply a strong drop shadow or a thick outline to make it pop. Consider a slight rotation or shear to the text for a dynamic feel. The color should be high-contrast against its background.`,
        `Text Style 2 (Elegant & Integrated): Use a clean, modern font that complements the theme (could be serif or sans-serif, like 'Montserrat' or 'Playfair Display'). The text should feel like a natural part of the image. Position it thoughtfully within the composition, perhaps interacting with elements in the image. Effects should be subtle, like a soft glow or a gentle gradient.`,
        `Text Style 3 (Creative & Unconventional): Experiment with a unique typographic layout. This could involve stacking words vertically, mixing font weights and sizes within the title, or placing text along a curve or shape within the image. Use a color palette for the text that is directly sampled from the image itself to create a cohesive look.`,
    ];

    requestPartsArray = textCreativeDirections.map((direction, index) => {
        const currentTheme = getThemeForIndex(index);
        const promptHeader = `
You are an expert typography and text placement designer.
**You will be asked to create 3 different text style options. You MUST follow the unique "Creative Direction for Text Style" for each one to ensure the typographic results are distinct.**

**PRIMARY GOAL: Add text to the provided image without altering the original image content.**

**ABSOLUTE CRITICAL TEXT RULE: You must use the following text VERBATIM. This means character-for-character, with exact spelling, capitalization, and punctuation. Double-check your spelling before finalizing the image. Any spelling mistake is a failure.**
- **Title Text (Verbatim):** "${title}"
- **Subtitle Text (Verbatim):** ${text ? `"${text}"` : 'None'}

**ABSOLUTE CRITICAL IMAGE RULE: The original image content must NOT be changed. To fit the target aspect ratio, you MUST add black bars (pillarboxing or letterboxing). DO NOT CROP, STRETCH, ZOOM, or DISTORT the original image content in any way.**

- **Theme/Style Guide for Text:** "${currentTheme}"

**Design Principles for Text:**
- **Text Readability Rule:** ${bannerInstruction}
- Text must be highly legible with strong contrast against the background image.
- Strategically place text following the rule of thirds. **Crucially, do not place text over a person's face or the main subject.**
- The text style (font, color, effects) should perfectly match the "Theme/Style Guide".
- Return ONLY the final image with text added. No additional commentary.
`;
        const promptText = `${universalPromptPrefix}${promptHeader}\n\n**Creative Direction for Text Style:** ${direction}`;
        return [imagePart, { text: promptText }];
    });
  } else {
    const getGenderInstruction = () => {
      switch (gender) {
          case 'me':
              return 'The person from the uploaded image MUST be kept and accurately represented. Do not replace them.';
          case 'male':
              return 'If a person is depicted, they must be male.';
          case 'female':
              return 'If a person is depicted, they must be female.';
          case 'none':
              return 'Do NOT include any person in the thumbnail. The focus should be solely on objects, text, and abstract design elements that relate to the video\'s theme.';
          case 'any':
          default:
              return 'If a person is depicted, you MUST generate a diverse set of people across the 3 thumbnail options. Ensure a balanced representation of various global ethnicities (e.g., White/Caucasian, Black/African descent, East Asian, Hispanic/Latino, etc.). Strive for variety in the generated people across the different creative directions to avoid showing the same ethnicity repeatedly.';
      }
    };
    const genderInstructionText = getGenderInstruction();


    // Three distinct creative directions for variety. Emphasize that this is about the art style, to be combined with the user's content theme.
    const creativeDirections = [
        `Art Style: Cinematic Photograph. The final output should be a hyper-realistic, dramatic photograph with high contrast, professional lighting, and a shallow depth of field. It should look like a still from a high-budget movie. Focus on realism and an intense, captivating mood. Avoid any digital painting or illustration feel.`,
        `Art Style: Expressive Digital Painting. The final output should be a highly artistic and expressive digital painting. Use visible brush strokes, rich textures, and a sophisticated color palette. The style should be painterly and moody, focusing on emotion rather than cartoony characters. Think high-quality concept art for a film.`,
        `Art Style: Minimalist Graphic Design. The final output should be a striking, minimalist graphic design focusing on typography. Use clean lines, geometric shapes, and a limited, high-contrast color palette. This style should feel modern and impactful, like a professional poster. Avoid illustrative characters; the text and abstract design should be the main focus.`,
    ];
    
    const createCommonPromptHeader = (currentTheme: string, direction: string) => `
You are an expert YouTube thumbnail designer. Your primary goal is to create a visually stunning and click-worthy image.
**You will be asked to generate 3 options. You MUST follow the unique "Creative Mandate" for each one to ensure the results are visually distinct.**

**1. Creative Mandate for THIS specific image generation:**
- **User's Content Theme:** "${currentTheme}"
- **Required Art Style:** ${direction}
- **Your Task:** Combine the user's theme with the required art style. Generate a high-quality image that perfectly embodies BOTH the content theme and the art style. All visual elements—background, subjects, colors, lighting—must align with this combined mandate.

**2. Gender Specification:** ${genderInstructionText}

**3. Text Overlay Task (Secondary):**
After creating the visual, you must overlay the following text. The text style should complement the **Creative Mandate**.

**ABSOLUTE CRITICAL TEXT RULE: You must use the following text VERBATIM. This means character-for-character, with exact spelling, capitalization, and punctuation. Double-check your spelling before finalizing the image. Any spelling mistake is a failure.**
- **Title Text (Verbatim):** "${title}"
- **Subtitle Text (Verbatim):** ${text ? `"${text}"` : 'None'}

**4. Final Design and Layout Rules:**
- **Text Readability Rule:** ${bannerInstruction}
- Text must be highly legible and strategically placed. **Crucially, do not place any text over a person's face.**
- Do not include any branding like the YouTube logo or play buttons.
- Return ONLY the generated image file. No additional text, commentary, or descriptions.
`;

    if (imageFile) {
        const imagePart = await fileToGenerativePart(imageFile);
        let imageSpecificTask: string;
        if (gender === 'me') {
          imageSpecificTask = `
**Image-Specific Task (Overrides Core Visual Task):**
You are provided an image containing a person. **Your task is to feature THIS PERSON in a newly generated scene.**
1.  **Identify and Isolate the Person:** Analyze the uploaded image to understand the person's appearance, key features, clothing, and pose.
2.  **Recreate the Person:** Re-draw the person, faithfully preserving their likeness, features, and pose. However, the rendering of the person MUST match the **Required Art Style** for this generation (e.g., if the art style is 'Digital Painting', the person should look painted; if 'Cinematic Photograph', they should look photorealistic).
3.  **Build a New Scene:** Create a brand new background and environment around the person that perfectly matches the **User's Content Theme**.
4.  **Integrate Text:** Add the required text elements (Title/Subtitle) naturally into the new scene, following all text rules.

**Crucial Rule:** The final image must feature a person who is clearly and recognizably the same individual from the uploaded photo, but seamlessly integrated into a new, stylistically consistent environment.`;
        } else {
          imageSpecificTask = `
**Image-Specific Task:**
You have been provided with a reference image. Your task is to generate a new thumbnail inspired by this image's theme, style, and subject matter, while strictly adhering to the "Gender Specification" from the main prompt.
- You have creative freedom to change the background, composition, and overall scene.
- If the original image contains a person but the Gender Specification is 'None', create a scene without any people.
- If the Gender Specification is 'Male', 'Female', or 'Any', ensure the person in the generated image complies with that rule, even if it means replacing a person from the original image.
- The overall mood and context should be derived from the reference image.
Integrate the text elements naturally into the new scene you create.`;
        }

        requestPartsArray = creativeDirections.map((direction, index) => {
            const currentTheme = getThemeForIndex(index);
            const commonPromptHeader = createCommonPromptHeader(currentTheme, direction);
            const imagePromptInstructions = `${commonPromptHeader}\n\n${imageSpecificTask}`;
            const promptText = `${universalPromptPrefix}${imagePromptInstructions}`;
            return [imagePart, { text: promptText }];
        });
    } else {
        requestPartsArray = creativeDirections.map((direction, index) => {
            const currentTheme = getThemeForIndex(index);
            const commonPromptHeader = createCommonPromptHeader(currentTheme, direction);
            const noImagePromptInstructions = `${commonPromptHeader}\n\n**Task:** Create a thumbnail from scratch based on the provided details.`;
            const promptText = `${universalPromptPrefix}${noImagePromptInstructions}`;
            return [{ text: promptText }];
        });
    }
  }
  
  const generatePromises = requestPartsArray.map(parts => 
    ai.models.generateContent({
      model: model,
      contents: { parts: parts },
      config: {
        responseModalities: [Modality.IMAGE],
      },
    })
  );

  try {
    const results = await Promise.allSettled(generatePromises);
    const imageUrls: string[] = [];
    
    results.forEach((result, index) => {
      if (result.status === 'fulfilled') {
        const response = result.value;
        const imagePart = response.candidates?.[0]?.content?.parts?.find(part => part.inlineData);
        if (imagePart?.inlineData) {
          const base64ImageBytes = imagePart.inlineData.data;
          imageUrls.push(`data:${imagePart.inlineData.mimeType};base64,${base64ImageBytes}`);
        } else {
            console.warn(`Generation promise ${index} succeeded but did not return a valid image part.`, response);
        }
      } else {
        console.error(`Thumbnail generation promise ${index} was rejected:`, result.reason);
      }
    });

    if (imageUrls.length === 0) {
        throw new Error("All thumbnail generation attempts failed. The model may have refused the requests. Please try a different prompt or check the console for details.");
    }

    return imageUrls;
  } catch (error) {
    console.error("Error generating thumbnails with Gemini:", error);
     if (error instanceof Error) {
        throw error;
    }
    throw new Error("An unexpected error occurred during thumbnail generation.");
  }
};
