
import { AspectRatio, ThumbnailStyle } from './types';

export const ASPECT_RATIO_OPTIONS: { value: AspectRatio; label: string }[] = [
  { value: AspectRatio.SixteenNine, label: '16:9 (YouTube Thumbnail)' },
  { value: AspectRatio.FourThree, label: '4:3 (Standard)' },
  { value: AspectRatio.OneOne, label: '1:1 (Social Media)' },
  { value: AspectRatio.NineSixteen, label: '9:16 (Shorts/Reels)' },
];

export const THUMBNAIL_STYLE_OPTIONS: { value: ThumbnailStyle; label: string }[] = [
  { value: ThumbnailStyle.Photorealistic, label: 'Photorealistic' },
  { value: ThumbnailStyle.DigitalArt, label: 'Digital Art' },
  { value: ThumbnailStyle.Cartoon, label: 'Cartoon' },
  { value: ThumbnailStyle.Minimalist, label: 'Minimalist' },
  { value: ThumbnailStyle.Cinematic, label: 'Cinematic' },
  { value: ThumbnailStyle.Vibrant, label: 'Vibrant Illustration' },
  { value: ThumbnailStyle.Vintage, label: 'Vintage' },
];
