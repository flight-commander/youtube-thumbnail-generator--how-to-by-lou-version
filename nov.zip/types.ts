
export interface GenerateThumbnailParams {
  videoUrl: string;
  title: string;
  text: string;
  theme: string;
  gender: string;
  withBanner: boolean;
  editInstruction?: string;
  aspectRatio: string;
}

export interface Part {
  text?: string;
  inlineData?: {
    mimeType: string;
    data: string;
  };
}

// FIX: Add AspectRatio enum for thumbnail options.
export enum AspectRatio {
  SixteenNine = '16:9',
  FourThree = '4:3',
  OneOne = '1:1',
  NineSixteen = '9:16',
}

// FIX: Add ThumbnailStyle enum for thumbnail options.
export enum ThumbnailStyle {
  Photorealistic = 'Photorealistic',
  DigitalArt = 'Digital Art',
  Cartoon = 'Cartoon',
  Minimalist = 'Minimalist',
  Cinematic = 'Cinematic',
  Vibrant = 'Vibrant Illustration',
  Vintage = 'Vintage',
}
