
import React, { useEffect } from 'react';
import { DownloadIcon, CloseIcon } from './icons';

interface PreviewModalProps {
  imageUrl: string;
  onClose: () => void;
  aspectRatio: string;
}

export const PreviewModal: React.FC<PreviewModalProps> = ({ imageUrl, onClose, aspectRatio }) => {
    useEffect(() => {
        const handleEsc = (event: KeyboardEvent) => {
           if (event.key === 'Escape') {
              onClose();
           }
        };
        window.addEventListener('keydown', handleEsc);
    
        return () => {
          window.removeEventListener('keydown', handleEsc);
        };
    }, [onClose]);

    const handleDownload = () => {
        const link = document.createElement('a');
        link.href = imageUrl;
        link.download = `thumbnail-${Date.now()}.png`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    const getAspectRatioClass = (ratio: string) => {
        switch(ratio) {
            case '1:1': return 'aspect-square';
            case '9:16': return 'aspect-[9/16]';
            case '16:9':
            default: return 'aspect-video';
        }
    };

    return (
        <div 
          className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 transition-opacity p-4"
          onClick={onClose}
          role="dialog"
          aria-modal="true"
          aria-labelledby="modal-title"
        >
          <div 
            className="bg-gray-800 rounded-lg shadow-2xl p-4 max-w-4xl w-full relative transform transition-all"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="absolute top-4 right-4 z-10">
              <button onClick={onClose} className="text-gray-400 hover:text-white transition-colors" aria-label="Close modal">
                <CloseIcon />
              </button>
            </div>
            
            <div className="p-4">
              <h2 id="modal-title" className="text-xl font-bold mb-4 text-center">Thumbnail Preview</h2>
              <div className={`${getAspectRatioClass(aspectRatio)} relative bg-gray-900 rounded-md overflow-hidden mx-auto max-w-full`} style={{ maxHeight: '70vh' }}>
                <img src={imageUrl} alt="Enlarged thumbnail preview" className="w-full h-full object-contain" />
              </div>
              <div className="mt-6 flex justify-center">
                <button
                  onClick={handleDownload}
                  className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-indigo-500"
                >
                  <DownloadIcon />
                  <span className="ml-2">Download Image</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      );
};
