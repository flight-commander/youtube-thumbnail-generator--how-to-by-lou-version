import React from 'react';

export const Header: React.FC = () => (
  <header className="text-center">
    <h1 className="text-4xl sm:text-5xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-indigo-600">
      AI YouTube Thumbnail Generator
    </h1>
    <p className="mt-4 max-w-2xl mx-auto text-lg text-gray-400">
      Craft the perfect thumbnail in seconds. Fill in the details, and let AI generate three stunning, click-worthy options for your next video.
    </p>
  </header>
);
