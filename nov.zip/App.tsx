
import React, { useState, useCallback, useRef, useEffect } from 'react';
import { Header } from './components/Header';
import { InputField } from './components/InputField';
import { Loader } from './components/Loader';
import { UploadIcon, TrashIcon, DownloadIcon } from './components/icons';
import { generateThumbnails } from './services/geminiService';
import type { GenerateThumbnailParams } from './types';
import { PreviewModal } from './components/PreviewModal';

const GENERATIONS_PER_MINUTE = 20;

const App: React.FC = () => {
  const [formData, setFormData] = useState<GenerateThumbnailParams>({
    videoUrl: '',
    title: '',
    text: '',
    theme: '',
    gender: 'any',
    withBanner: false,
    editInstruction: '',
    aspectRatio: '16:9',
  });
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isFetchingThumbnail, setIsFetchingThumbnail] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [generatedThumbnails, setGeneratedThumbnails] = useState<string[]>([]);
  const [selectedThumbnail, setSelectedThumbnail] = useState<string | null>(null);
  const [remainingGenerations, setRemainingGenerations] = useState(GENERATIONS_PER_MINUTE);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const timer = setInterval(() => {
      setRemainingGenerations(GENERATIONS_PER_MINUTE);
    }, 60000); // Reset every 60 seconds

    return () => clearInterval(timer); // Cleanup on component unmount
  }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { id, value } = e.target;
    setFormData(prev => ({ ...prev, [id]: value }));
  };

  const handleCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { id, checked } = e.target;
    setFormData(prev => ({ ...prev, [id]: checked }));
  };

  const handleFileChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 4 * 1024 * 1024) { // 4MB limit
        setError("Image size should not exceed 4MB.");
        return;
      }
      setError(null);
      setImageFile(file);
      if (imagePreview) {
        URL.revokeObjectURL(imagePreview);
      }
      const previewUrl = URL.createObjectURL(file);
      setImagePreview(previewUrl);
    }
  }, [imagePreview]);
  
  useEffect(() => {
    return () => {
        if (imagePreview) {
            URL.revokeObjectURL(imagePreview);
        }
    };
  }, [imagePreview]);

  const removeImage = useCallback(() => {
    setImageFile(null);
    if (imagePreview) {
      URL.revokeObjectURL(imagePreview);
      setImagePreview(null);
    }
    if (fileInputRef.current) {
        fileInputRef.current.value = "";
    }
    if (['me', 'original', 'edit'].includes(formData.gender)) {
      setFormData(prev => ({ ...prev, gender: 'any' }));
    }
  }, [imagePreview, formData.gender]);

  const extractYouTubeID = (url: string): string | null => {
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/;
    const match = url.match(regExp);
    return (match && match[2].length === 11) ? match[2] : null;
  };

  const handleUrlBlur = async () => {
    if (!formData.videoUrl) return;

    const videoId = extractYouTubeID(formData.videoUrl);
    if (!videoId) return;

    setIsFetchingThumbnail(true);
    setError(null);
    
    const thumbnailUrlsToTry = [
      `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`,
      `https://img.youtube.com/vi/${videoId}/sddefault.jpg`,
      `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`,
    ];

    let thumbnailFetched = false;

    for (const url of thumbnailUrlsToTry) {
        try {
            const response = await fetch(url);
            if (response.ok) {
                const blob = await response.blob();
                const file = new File([blob], `${videoId}.jpg`, { type: 'image/jpeg' });

                if (file.size > 4 * 1024 * 1024) {
                  // If it's too big, try the next smaller resolution.
                  continue;
                }
                
                setImageFile(file);
                if (imagePreview) {
                  URL.revokeObjectURL(imagePreview);
                }
                setImagePreview(URL.createObjectURL(file));
                thumbnailFetched = true;
                break; // Success, exit loop
            }
        } catch (err) {
            console.error(`Error fetching thumbnail from ${url}:`, err);
            // This will catch network errors, and the loop will continue.
        }
    }

    if (!thumbnailFetched) {
      setError("Could not fetch thumbnail from URL. The video may be private, deleted, or has no available thumbnail.");
    }
    
    setIsFetchingThumbnail(false);
  };

  const handleDownload = (e: React.MouseEvent<HTMLButtonElement>, imageUrl: string) => {
    e.stopPropagation(); // Prevent the modal from opening
    const link = document.createElement('a');
    link.href = imageUrl;
    link.download = `thumbnail-${Date.now()}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };


  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError(null);

    if (remainingGenerations <= 0) {
      setError("You've reached the rate limit. Please wait a minute before generating more.");
      return;
    }

    if (!formData.title || !formData.theme) {
      setError('Title and Theme are required fields.');
      return;
    }
    
    if (formData.gender === 'edit' && (!formData.editInstruction || formData.editInstruction.trim() === '')) {
      setError('Editing instructions are required when using the Edit option.');
      return;
    }

    setRemainingGenerations(prev => prev - 1);
    setIsLoading(true);
    setGeneratedThumbnails([]);

    try {
      const thumbnails = await generateThumbnails(formData, imageFile);
      setGeneratedThumbnails(thumbnails);
    } catch (err) {
      console.error("Thumbnail generation failed:", err);
      setError('The AI may have refused the request due to content policy violations or if the prompt was too complex. Try simplifying your request or adjusting the theme.');
    } finally {
      setIsLoading(false);
    }
  };

  const counterColorClass = remainingGenerations > 5 
    ? 'text-green-400' 
    : remainingGenerations > 0 
    ? 'text-yellow-400' 
    : 'text-red-500';
    
  const getAspectRatioClass = (ratio: string) => {
    switch(ratio) {
        case '1:1': return 'aspect-square';
        case '9:16': return 'aspect-[9/16]';
        case '16:9':
        default: return 'aspect-video';
    }
  }

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 font-sans">
      <main className="container mx-auto px-4 py-8">
        <Header />

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mt-8">
          {/* Form Section */}
          <div className="bg-gray-800 p-8 rounded-2xl shadow-2xl">
            <form onSubmit={handleSubmit} className="space-y-6">
              <InputField id="videoUrl" label="Video URL (optional)" value={formData.videoUrl} onChange={handleInputChange} onBlur={handleUrlBlur} placeholder="https://youtube.com/watch?v=..." isLoading={isFetchingThumbnail} />
              <InputField id="title" label="Thumbnail Title" value={formData.title} onChange={handleInputChange} placeholder="e.g., My Craziest Adventure!" required />
              <InputField id="text" label="Thumbnail Text (optional)" value={formData.text} onChange={handleInputChange} placeholder="e.g., You Won't Believe This!" />
              
              <div className="flex items-center pt-2">
                <input
                  id="withBanner"
                  name="withBanner"
                  type="checkbox"
                  checked={formData.withBanner}
                  onChange={handleCheckboxChange}
                  className="h-4 w-4 rounded border-gray-500 bg-gray-700 text-indigo-600 focus:ring-indigo-600"
                />
                <label htmlFor="withBanner" className="ml-3 block text-sm font-medium text-gray-300 select-none">
                  Add banner behind text for readability
                </label>
              </div>

              <InputField id="theme" label="Thumbnail Theme / Style" value={formData.theme} onChange={handleInputChange} placeholder="e.g., Vibrant, Comic Book Style, Dark Fantasy" required />
              
              <div>
                <label htmlFor="aspectRatio" className="block text-sm font-medium text-gray-400 mb-2">Aspect Ratio</label>
                <select
                  id="aspectRatio"
                  name="aspectRatio"
                  value={formData.aspectRatio}
                  onChange={handleInputChange}
                  className="w-full bg-gray-700 border border-gray-600 rounded-md shadow-sm py-2 px-3 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
                >
                  <option value="16:9">YouTube Thumbnail (16:9)</option>
                  <option value="1:1">Instagram Post (1:1)</option>
                  <option value="9:16">Shorts / Reels / TikTok (9:16)</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">Image / Person Handling</label>
                <div className="grid grid-cols-3 gap-2 rounded-md" role="radiogroup">
                    {['any', 'male', 'female', 'none', 'me', 'original', 'edit'].map((option) => {
                       const isImageRequired = ['me', 'original', 'edit'].includes(option);
                       const isDisabled = isImageRequired && !imageFile;
                       const getTitle = () => {
                            if (isDisabled) return 'Upload an image to enable this option';
                            if (option === 'me') return 'Recreate the scene with the person from your uploaded image, matching the new theme and style.';
                            if (option === 'original') return 'Use the uploaded image as is and only add text';
                            if (option === 'edit') return 'Edit the uploaded image with instructions';
                            return '';
                       }
                       return (
                        <button
                            key={option}
                            type="button"
                            role="radio"
                            aria-checked={formData.gender === option}
                            onClick={() => !isDisabled && setFormData(prev => ({ ...prev, gender: option }))}
                            disabled={isDisabled}
                            title={getTitle()}
                            className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-indigo-500 ${
                                formData.gender === option
                                    ? 'bg-indigo-600 text-white shadow-md'
                                    : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                            } ${isDisabled ? 'opacity-50 cursor-not-allowed' : ''}`}
                        >
                            {option.charAt(0).toUpperCase() + option.slice(1)}
                        </button>
                       )
                    })}
                </div>
                {['me', 'original', 'edit'].includes(formData.gender) && !imageFile && (
                  <div className="mt-3 text-center text-sm text-yellow-400 bg-yellow-900/50 p-3 rounded-md">
                    Please upload an image to use the <span className="font-bold">{formData.gender.charAt(0).toUpperCase() + formData.gender.slice(1)}</span> option.
                  </div>
                )}
                {formData.gender === 'edit' && (
                  <div className="mt-4">
                    <InputField
                      id="editInstruction"
                      label="Editing Instructions"
                      value={formData.editInstruction || ''}
                      onChange={handleInputChange}
                      placeholder="e.g., remove the text, change background to blue"
                      required
                    />
                  </div>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">Upload Image (optional)</label>
                <div 
                  className="mt-2 flex justify-center items-center px-6 pt-5 pb-6 border-2 border-gray-600 border-dashed rounded-md cursor-pointer hover:border-indigo-500 transition-colors"
                  onClick={() => fileInputRef.current?.click()}
                >
                  <div className="space-y-1 text-center">
                    <UploadIcon />
                    <div className="flex text-sm text-gray-500">
                      <p className="pl-1">Upload a file or drag and drop</p>
                    </div>
                    <p className="text-xs text-gray-600">PNG, JPG, GIF up to 4MB</p>
                  </div>
                  <input ref={fileInputRef} id="file-upload" name="file-upload" type="file" className="sr-only" onChange={handleFileChange} accept="image/png, image/jpeg, image/gif"/>
                </div>
              </div>

              {imagePreview && (
                <div className="relative">
                  <p className="text-sm font-medium text-gray-400 mb-2">Image Preview:</p>
                  <img src={imagePreview} alt="Preview" className="rounded-lg w-full h-auto object-cover" />
                  <button type="button" onClick={removeImage} className="absolute top-2 right-2 bg-red-600 hover:bg-red-700 text-white rounded-full p-2 transition-transform duration-200 hover:scale-110">
                    <TrashIcon />
                  </button>
                </div>
              )}

              <div className="text-center pt-2">
                <p className="text-sm text-gray-400">
                  Generations left this minute:
                  <span className={`font-bold ml-2 ${counterColorClass}`}>
                    {remainingGenerations} / {GENERATIONS_PER_MINUTE}
                  </span>
                </p>
                {remainingGenerations <= 0 && (
                    <p className="text-xs text-gray-500 mt-1">Limit resets every minute. Please wait.</p>
                )}
              </div>
              
              <button type="submit" disabled={isLoading || remainingGenerations <= 0} className="w-full flex justify-center items-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:bg-gray-500 disabled:cursor-not-allowed">
                {isLoading ? <Loader /> : 'Generate Thumbnails'}
              </button>
            </form>
          </div>

          {/* Results Section */}
          <div className="bg-gray-800 p-8 rounded-2xl shadow-2xl flex flex-col justify-center items-center">
            {isLoading && (
              <div className="text-center">
                <Loader size="lg"/>
                <p className="mt-4 text-lg text-gray-400 animate-pulse">Generating your masterpieces...</p>
                <p className="text-sm text-gray-500">This might take a moment.</p>
              </div>
            )}
            {error && <div className="text-red-400 bg-red-900/50 p-4 rounded-lg">{error}</div>}
            
            {!isLoading && generatedThumbnails.length === 0 && !error && (
               <div className="text-center text-gray-500">
                 <h3 className="text-xl font-semibold text-gray-300">Your Thumbnails Await</h3>
                 <p className="mt-2">Fill out the form to see the magic happen!</p>
               </div>
            )}

            {generatedThumbnails.length > 0 && (
              <div className="w-full">
                <h2 className="text-2xl font-bold mb-2 text-center">Your Results</h2>
                <p className="text-center text-gray-400 mb-6">Click to preview, or hover to download. ({generatedThumbnails.length} option{generatedThumbnails.length > 1 ? 's' : ''} generated)</p>
                <div className="grid grid-cols-1 gap-6">
                  {generatedThumbnails.map((src, index) => (
                    <div 
                      key={index}
                      onClick={() => setSelectedThumbnail(src)}
                      className={`${getAspectRatioClass(formData.aspectRatio)} relative mx-auto w-full max-w-md bg-gray-700 rounded-lg overflow-hidden shadow-lg transition-transform duration-300 hover:scale-105 hover:shadow-indigo-500/50 cursor-pointer group`}
                    >
                      <img src={src} alt={`Generated thumbnail ${index + 1}`} className="w-full h-full object-cover" />
                      
                      <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-40 transition-opacity duration-300"></div>

                      <button
                        onClick={(e) => handleDownload(e, src)}
                        aria-label="Download thumbnail"
                        title="Download thumbnail"
                        className="absolute bottom-4 right-4 bg-indigo-600 text-white p-3 rounded-full shadow-lg opacity-0 group-hover:opacity-100 transition-all duration-300 hover:bg-indigo-700 hover:scale-110 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-indigo-500"
                      >
                        <DownloadIcon />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {selectedThumbnail && (
          <PreviewModal 
            imageUrl={selectedThumbnail} 
            aspectRatio={formData.aspectRatio}
            onClose={() => setSelectedThumbnail(null)} 
          />
        )}
      </main>
    </div>
  );
};

export default App;
